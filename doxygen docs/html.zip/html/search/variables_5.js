var searchData=
[
  ['parentupdate_97',['parentUpdate',['../classgodspeed_1_1framework_1_1_data_sink.html#a93add5a1aecacafcb33e79bfaa6c4939',1,'godspeed::framework::DataSink']]]
];
