var searchData=
[
  ['framework_63',['framework',['../namespaceframework.html',1,'']]]
];
