var searchData=
[
  ['source_5f_101',['source_',['../classgodspeed_1_1framework_1_1_data_sink.html#aeff5f62b62dabfb5e50f91c8385680d2',1,'godspeed::framework::DataSink']]],
  ['subscribe_102',['subscribe',['../classgodspeed_1_1framework_1_1_data_source.html#afcbc19dec2c379541b14d4c304d880bb',1,'godspeed::framework::DataSource']]]
];
