var searchData=
[
  ['value_87',['value',['../classgodspeed_1_1framework_1_1_data_sink_b.html#a9bfd894000cc377387b52a43efb28237',1,'godspeed::framework::DataSinkB::value()'],['../classgodspeed_1_1framework_1_1_data_sink_d.html#a103da9f13a81c0f831b4da5b9f4c4e36',1,'godspeed::framework::DataSinkD::value()']]]
];
