var searchData=
[
  ['connect_68',['connect',['../classgodspeed_1_1framework_1_1_data_sink.html#a869242509f063ca7f289939e577d7399',1,'godspeed::framework::DataSink']]]
];
