var searchData=
[
  ['framework_13',['framework',['../namespaceframework.html',1,'']]]
];
