var searchData=
[
  ['desiredmax_90',['desiredMax',['../classgodspeed_1_1framework_1_1_data_sink_d.html#ae673bef9b139bb62c3bdfb1774427f71',1,'godspeed::framework::DataSinkD']]],
  ['desiredmin_91',['desiredMin',['../classgodspeed_1_1framework_1_1_data_sink_d.html#a5053d32cbea54ebfa56e8123fead3f48',1,'godspeed::framework::DataSinkD']]],
  ['downbutton_92',['downButton',['../classgodspeed_1_1inputs_1_1_remote_controller.html#a3cdf98c02d254812fe6a1f948bdbbb93',1,'godspeed::inputs::RemoteController']]]
];
